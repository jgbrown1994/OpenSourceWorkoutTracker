# Equipment Service

This service will allow users to add equipment types and read equipment types required for their workouts.

The DB will have: uuid, name, weight, plateWeights, substitutes, createdAt, createdBy, modifiedAt, modifiedBy

The API will support GET, POST and DELETE